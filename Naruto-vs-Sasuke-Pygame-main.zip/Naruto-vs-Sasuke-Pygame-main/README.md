# Naruto-vs-Sasuke-Pygame
Naruto vs Sasuke game made in Python Pygame .

This is a game made in Python pygames
all assests are given, just downlaod and run it

be sure to insatll Pygame first, it is a module to make 2d game in python.
